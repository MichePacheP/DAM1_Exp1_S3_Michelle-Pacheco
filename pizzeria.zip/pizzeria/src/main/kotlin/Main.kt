package org.example

fun main() {
    val clientes = mutableListOf<Cliente>()
    val productos = mutableListOf<Producto>(
        Pizza("Margarita", 8000.0),
        Pizza("Pepperoni", 9500.0),
        Combo("Combo Familiar", 18000.0),
        Bebida("Coca-Cola", 2000.0),
        Ingrediente("Queso extra", 1000.0)
    )
    val pedidos = mutableListOf<Pedido>()
    while (true) {
        println("\n1. Registrar cliente\n2. Crear pedido\n3. Ver pedidos\n4. Ver promocionables\n5. Analizar clase (reflection)\n6. Combinar dos pedidos\n7. Registrar producto\n8. Ver resumen\n9. Cargar datos de ejemplo\n0. Salir")
        when (readln().trim()) {
            "1" -> {
                print("Nombre: ")
                val nombre = readln().trim()
                val nuevo = Cliente(nombre, pedirEmail(), pedirTelefono())
                if (nuevo in clientes) println("Error: ese cliente ya esta registrado.")
                else { clientes.add(nuevo); println("Cliente registrado.") }
            }
            "2" -> {
                if (clientes.isEmpty()) { println("Primero registra un cliente."); continue }
                clientes.forEachIndexed { i, c -> println("$i) $c") }
                print("Elige cliente: ")
                val cliente = clientes.getOrNull(readln().toIntOrNull() ?: -1)
                if (cliente == null) { println("Cliente invalido."); continue }

                val pedido = Pedido(cliente, fecha = pedirFecha())
                do {
                    productos.forEachIndexed { i, p -> println("$i) $p") }
                    print("Elige producto: ")
                    val prod = productos.getOrNull(readln().toIntOrNull() ?: -1)
                    if (prod == null) println("Producto invalido.")
                    else pedido.agregar(prod, pedirCantidad())
                    print("¿Agregar otro? (s/n): ")
                } while (readln().trim().lowercase() == "s")

                pedidos.add(pedido)
                println(pedido)
            }
            "3" -> pedidos.forEach { pedido ->
                println(pedido)
                val (cliente, productosPedido, total) = pedido
                val (nombre, email, telefono) = cliente
                println("  Cliente: $nombre | $email | $telefono")
                println("  Productos: ${productosPedido.joinToString { it.nombre }}")
                println("  Total: $total")
            }
            "4" -> productos.forEach {
                val marca = if (esPromocionable(it)) "SÍ (${(descuentoDe(it) * 100).toInt()}%)" else "no"
                println("${it.nombre}: promocionable $marca")
            }
            "5" -> {
                listarMiembros(Cliente::class)
                listarMiembros(Producto::class)
                listarMiembros(Pedido::class)
            }
            "6" -> {
                if (pedidos.size < 2) { println("Necesitas al menos 2 pedidos."); continue }
                pedidos.forEachIndexed { i, p -> println("$i) $p") }
                print("Primer pedido: ")
                val a = pedidos.getOrNull(readln().toIntOrNull() ?: -1)
                print("Segundo pedido: ")
                val b = pedidos.getOrNull(readln().toIntOrNull() ?: -1)
                if (a == null || b == null || a === b) { println("Seleccion invalida."); continue }
                val unido = a + b
                pedidos.add(unido)
                println("Combinado: $unido")
            }
            "7" -> {
                print("Nombre: ")
                val nombre = readln().trim()
                print("Categoria (1=Pizza, 2=Bebida, 3=Ingrediente): ")
                val cat = readln().trim()
                print("Precio: ")
                val precio = readln().toDoubleOrNull()
                if (nombre.isEmpty() || precio == null || precio <= 0) { println("Datos invalidos."); continue }

                val nuevo: Producto? = when (cat) {
                    "1" -> Pizza(nombre, precio)
                    "2" -> Bebida(nombre, precio)
                    "3" -> Ingrediente(nombre, precio)
                    else -> null
                }
                if (nuevo == null) println("Categoria invalida.")
                else if (nuevo in productos) println("Error: ese producto ya existe.")
                else { productos.add(nuevo); println("Producto registrado.") }
            }
            "8" -> mostrarResumen(clientes, productos, pedidos)
            "9" -> {
                val c1 = Cliente("Ana Perez", "ana@correo.com", "+56 (912) 345-6789")
                val c2 = Cliente("Luis Soto", "luis@correo.com", "+56 (987) 654-3210")
                if (c1 in clientes) { println("Los datos de ejemplo ya fueron cargados."); continue }
                if (c1 !in clientes) clientes.add(c1)
                if (c2 !in clientes) clientes.add(c2)

                val p1 = Pedido(c1)
                p1.agregar(productos[0], 2)   // 2 Margarita
                p1.agregar(productos[3], 1)   // 1 Coca-Cola
                val p2 = Pedido(c1)
                p2.agregar(productos[2], 1)   // 1 Combo Familiar
                p2.agregar(productos[4], 3)   // 3 Queso extra
                pedidos.add(p1)
                pedidos.add(p2)
                println("Datos de ejemplo cargados.")
            }
            "0" -> return
            else -> println("Opcion invalida.")
        }
    }
}