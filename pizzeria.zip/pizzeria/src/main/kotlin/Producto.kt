package org.example

open class Producto(
    val nombre: String,
    val categoria: Categoria,
    val precio: Double,
    var stock: Int = 50
) {
    override fun toString() = "$nombre ($categoria) - $$precio [stock: $stock]"
    /* En Kotlin, == llama a equals(): dos productos son iguales si coinciden nombre y categoría. */
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Producto) return false
        return nombre.equals(other.nombre, ignoreCase = true) && categoria == other.categoria
    }

    override fun hashCode(): Int = nombre.lowercase().hashCode() * 31 + categoria.hashCode()
}

@Promocionable(descuento = 0.15)
class Pizza(nombre: String, precio: Double, stock: Int = 50) :
    Producto(nombre, Categoria.PIZZA, precio, stock)

@Promocionable(descuento = 0.20)
class Combo(nombre: String, precio: Double, stock: Int = 50) :
    Producto(nombre, Categoria.PIZZA, precio, stock)

class Bebida(nombre: String, precio: Double, stock: Int = 50) :
    Producto(nombre, Categoria.BEBIDA, precio, stock)

class Ingrediente(nombre: String, precio: Double, stock: Int = 50) :
    Producto(nombre, Categoria.INGREDIENTE, precio, stock)