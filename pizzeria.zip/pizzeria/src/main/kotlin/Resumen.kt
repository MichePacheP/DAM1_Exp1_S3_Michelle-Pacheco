package org.example

import kotlin.reflect.full.findAnnotation
import java.time.LocalDate

private const val LINEA = "========================================================"
private const val SUB = "--------------------------------------------------------"

fun mostrarResumen(
    clientes: List<Cliente>,
    productos: List<Producto>,
    pedidos: List<Pedido>
) {
    println("\n$LINEA")
    println("        RESUMEN - PIZZERIA")
    println(LINEA)

    // 1. Pedidos combinados con el operador +
    println("\n1. PEDIDOS COMBINADOS (operador +)")
    println(SUB)
    if (pedidos.size >= 2) {
        val combinado = pedidos[0] + pedidos[1]
        println("Pedido A: ${pedidos[0]}")
        println("Pedido B: ${pedidos[1]}")
        println("A + B   : $combinado")
        println("Items combinados:")
        combinado.items.forEach {
            println("  - ${it.cantidad} x ${it.producto.nombre}: $${it.subtotal}")
        }
        println("Total sin descuento: $${combinado.totalSinDescuento()}")
        println("Total final        : $${combinado.total()}")
    } else {
        println("Se necesitan al menos 2 pedidos para combinar.")
    }

    // 2. Cliente desestructurado
    println("\n2. CLIENTE DESESTRUCTURADO")
    println(SUB)
    if (clientes.isNotEmpty()) {
        val (nombre, email, telefono) = clientes.first()
        println("Nombre  : $nombre")
        println("Correo  : $email")
        println("Telefono: $telefono")
    } else {
        println("No hay clientes registrados.")
    }

    if (pedidos.isNotEmpty()) {
        val (cliente, prods, total) = pedidos.first()
        println("\nPedido desestructurado:")
        println("  Cliente  : ${cliente.nombre}")
        println("  Productos: ${prods.joinToString { it.nombre }}")
        println("  Total    : $$total")
    }

    // 3. Productos promocionables (anotación)
    println("\n3. PRODUCTOS PROMOCIONABLES (@Promocionable)")
    println(SUB)
    productos.forEach {
        if (esPromocionable(it)) {
            println("  [SI] ${it.nombre} - ${(descuentoDe(it) * 100).toInt()}% de descuento")
        } else {
            println("  [no] ${it.nombre}")
        }
    }

    // 4. Validación de igualdad
    println("\n4. VALIDACION DE IGUALDAD (equals / hashCode)")
    println(SUB)
    if (clientes.isNotEmpty()) {
        val c = clientes.first()
        val copia = Cliente(c.nombre.uppercase(), c.email.uppercase(), "000000000000")
        println("Cliente == misma persona (otro formato, otro telefono): ${c == copia}")
        println("Mismo hashCode: ${c.hashCode() == copia.hashCode()}")
    }
    if (productos.isNotEmpty()) {
        val p = productos.first()
        val mismo = Pizza(p.nombre.lowercase(), p.precio + 500)
        val otraCategoria = Bebida(p.nombre, p.precio)
        println("Producto == mismo nombre y categoria, otro precio: ${p == mismo}")
        println("Producto == mismo nombre, distinta categoria     : ${p == otraCategoria}")
    }
    val sinDuplicados = (clientes + clientes).toSet().size
    println("Clientes unicos en un Set (lista duplicada a proposito): $sinDuplicados")

    println("\n5. VALIDACIONES (regex y ranges)")
    println(SUB)
    println("Correo 'ana@correo.com'      : ${esEmailValido("ana@correo.com")}")
    println("Correo 'hola'                : ${esEmailValido("hola")}")
    println("Telefono '569123456789'      : ${formatearTelefono("569123456789")}")
    println("Telefono '123'               : ${formatearTelefono("123") ?: "invalido"}")
    println("2026-11-15 en promocion      : ${estaEnPromocion(LocalDate.of(2026, 11, 15))}")
    println("2026-12-15 en promocion      : ${estaEnPromocion(LocalDate.of(2026, 12, 15))}")
    println("Cantidad 50 en rango 1-100   : ${50 in RANGO_CANTIDAD}")
    println("Cantidad 101 en rango 1-100  : ${101 in RANGO_CANTIDAD}")

    println("\n$LINEA")
    println("        FIN DEL RESUMEN")
    println(LINEA)
}