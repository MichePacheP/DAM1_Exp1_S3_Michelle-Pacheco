package org.example

import kotlin.reflect.KClass
import kotlin.reflect.full.memberFunctions
import kotlin.reflect.full.memberProperties

fun listarMiembros(clase: KClass<*>) {
    println("\n=== Clase: ${clase.simpleName} ===")

    println("Propiedades:")
    clase.memberProperties.forEach {
        println("  ${it.name}: ${it.returnType}")
    }

    println("Metodos:")
    clase.memberFunctions.forEach { f ->
        val params = f.parameters.drop(1)   // el primero es la instancia (this)
            .joinToString { "${it.name}: ${it.type}" }
        println("  ${f.name}($params): ${f.returnType}")
    }
}