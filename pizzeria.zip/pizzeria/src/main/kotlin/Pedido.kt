package org.example

import java.time.LocalDate

class ItemPedido(val producto: Producto, val cantidad: Int) {
    val subtotal: Double get() = producto.precio * cantidad
}

class Pedido(
    val cliente: Cliente,
    val items: MutableList<ItemPedido> = mutableListOf(),
    val fecha: LocalDate = LocalDate.now()
) {
    fun agregar(producto: Producto, cantidad: Int): Boolean {
        if (cantidad !in RANGO_CANTIDAD) return false
        if (producto.stock < cantidad) {
            println("Stock insuficiente de ${producto.nombre}")
            return false
        }
        producto.stock -= cantidad
        items.add(ItemPedido(producto, cantidad))
        return true
    }

    fun totalSinDescuento(): Double = items.sumOf { it.subtotal }

    fun total(): Double {
        if (!estaEnPromocion(fecha)) return totalSinDescuento()
        return items.sumOf { it.subtotal * (1 - descuentoDe(it.producto)) }
    }

    override fun toString() = "Pedido de ${cliente.nombre} ($fecha): ${items.size} items, total $${total()}"

    /* Combina dos pedidos: suma los ítems y el total se recalcula con descuentos. */
    operator fun plus(otro: Pedido): Pedido {
        val combinado = Pedido(cliente, mutableListOf(), maxOf(fecha, otro.fecha))
        combinado.items.addAll(this.items)
        combinado.items.addAll(otro.items)
        return combinado
    }

    /* Permite desestructurar: val (cliente, productos, total) = pedido */
    operator fun component1() = cliente
    operator fun component2() = items.map { it.producto }
    operator fun component3() = total()
}