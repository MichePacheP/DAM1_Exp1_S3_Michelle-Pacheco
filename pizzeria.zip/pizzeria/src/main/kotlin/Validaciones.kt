package org.example

import java.time.LocalDate
import java.time.format.DateTimeParseException

fun pedirFecha(): LocalDate {
    while (true) {
        print("Fecha del pedido (AAAA-MM-DD, Enter = hoy): ")
        val texto = readln().trim()
        if (texto.isEmpty()) return LocalDate.now()
        try {
            return LocalDate.parse(texto)
        } catch (e: DateTimeParseException) {
            println("Error: fecha inválida. Ejemplo: 2026-11-15")
        }
    }
}

val EMAIL_REGEX = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
val RANGO_CANTIDAD = 1..100
val PERIODO_PROMO: ClosedRange<LocalDate> =
    LocalDate.of(2026, 11, 1)..LocalDate.of(2026, 11, 30)

fun esEmailValido(email: String) = EMAIL_REGEX.matches(email)

fun formatearTelefono(telefono: String): String? {
    val digitos = telefono.filter { it.isDigit() }
    if (digitos.length != 12) return null
    return Regex("(\\d{2})(\\d{3})(\\d{3})(\\d{4})").replace(digitos, "+$1 ($2) $3-$4")
}

fun estaEnPromocion(fecha: LocalDate) = fecha in PERIODO_PROMO

fun aplicarDescuentoPromo(total: Double, fecha: LocalDate, porcentaje: Double = 0.10) =
    if (estaEnPromocion(fecha)) total * (1 - porcentaje) else total

fun pedirEmail(): String {
    while (true) {
        print("Correo: ")
        val email = readln().trim()
        if (esEmailValido(email)) return email
        println("Error: formato invalido. Ejemplo: nombre@dominio.com")
    }
}

fun pedirTelefono(): String {
    while (true) {
        print("Telefono (ej: 569123456789 con codigo de pais): ")
        val tel = formatearTelefono(readln())
        if (tel != null) return tel
        println("Error: debe tener 12 digitos (2 del pais + 10).")
    }
}

fun pedirCantidad(): Int {
    while (true) {
        print("Cantidad (1-100): ")
        val n = readln().toIntOrNull()
        if (n != null && n in RANGO_CANTIDAD) return n
        println("Error: ingrese un numero entre 1 y 100.")
    }
}