package org.example

class Cliente(val nombre: String, val email: String, val telefono: String) {

    /* Permite desestructurar: val (nombre, email, telefono) = cliente */
    operator fun component1() = nombre
    operator fun component2() = email
    operator fun component3() = telefono

    /* Dos clientes son iguales si coinciden nombre y correo (sin distinguir mayúsculas). */
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Cliente) return false
        return nombre.equals(other.nombre, ignoreCase = true) &&
                email.equals(other.email, ignoreCase = true)
    }

    override fun hashCode(): Int = nombre.lowercase().hashCode() * 31 + email.lowercase().hashCode()

    override fun toString() = "$nombre | $email | $telefono"
}