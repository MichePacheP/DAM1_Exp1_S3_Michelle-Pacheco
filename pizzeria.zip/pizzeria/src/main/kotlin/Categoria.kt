package org.example

enum class Categoria { PIZZA, BEBIDA, INGREDIENTE }