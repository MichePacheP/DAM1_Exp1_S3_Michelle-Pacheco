package org.example

import kotlin.reflect.full.findAnnotation
import kotlin.reflect.full.hasAnnotation

/* Anotación que marca productos elegibles para promociones. Se lee en tiempo de ejecución con reflection. */
@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class Promocionable(val descuento: Double = 0.10)

fun esPromocionable(p: Producto): Boolean = p::class.hasAnnotation<Promocionable>()

fun descuentoDe(p: Producto): Double =
    p::class.findAnnotation<Promocionable>()?.descuento ?: 0.0